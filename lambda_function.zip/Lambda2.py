import json
import boto3
import pandas as pd
import io

s3 = boto3.client('s3', endpoint_url='http://localhost:4566')
dynamodb = boto3.resource('dynamodb', endpoint_url='http://localhost:4566')

def lambda_handler(event, context):
    # Extract S3 bucket and file details from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Download the spreadsheet from S3
    s3_object = s3.get_object(Bucket=bucket, Key=key)
    spreadsheet = s3_object['Body'].read()
    
    # Convert Excel to CSV
    df = pd.read_excel(io.BytesIO(spreadsheet), engine='openpyxl')  # Use openpyxl for .xlsx
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)

    # Parse CSV and Insert into DynamoDB
    csv_buffer.seek(0)
    table = dynamodb.Table('OnCallSchedule')
    
    for index, row in df.iterrows():
        table.put_item(
            Item={
                'ID': str(index),
                'Name': row['Name'],
                'Date': row['Date'],
                'OnCall': row['OnCall']
            }
        )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Data imported successfully')
    }