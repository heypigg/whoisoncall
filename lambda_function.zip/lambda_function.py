import json
import boto3

dynamodb = boto3.resource('dynamodb', endpoint_url='http://localhost:4566')

def lambda_handler(event, context):
    table = dynamodb.Table('OnCallSchedule')
    # Perform read/write operations here
    return {
        'statusCode': 200,
        'body': json.dumps('Operation successful')
    }